package com.telstra.codechallenge.zerofollowers;

import java.lang.invoke.MethodHandles;
import java.text.ParseException;
import java.util.List;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ZeroFollowersController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
	@Autowired
	public ZeroFollowersService zeroFollowersService;
	
	@RequestMapping(path = "/zeroFollowers", method = RequestMethod.GET)
	public List<ZeroFollowers> hotestRepo() throws JSONException, ParseException {
		LOGGER.info("In Zero Followeres Controller");
		return zeroFollowersService.zeroFollowres();
	}
	

}
