package com.telstra.codechallenge.hottestrepo;

import java.util.Comparator;

public class SortRepoData implements Comparator<HottestRepoCreatedLastWeek> {
	@Override
	public int compare(HottestRepoCreatedLastWeek o1, HottestRepoCreatedLastWeek o2) {
		if (Integer.parseInt(o1.getWatchersCount()) < Integer.parseInt(o2.getWatchersCount())) {
			return 1;
		} else {
			return -1;
		}
	}

}
