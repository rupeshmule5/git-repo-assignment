package com.telstra.codechallenge.hottestrepo;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HottestRepoCreatedLastWeekService {

	@Value("${GitRepo.base.url}")
	private String GitRepoBaseUrl;
	
	
	private RestTemplate restTemplate;

	private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	public HottestRepoCreatedLastWeekService(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public List<HottestRepoCreatedLastWeek> hottestRepository() {

		LOGGER.info("In the HottestRepoCreatedLastWeekService service");

		HottestRepoCreatedLastWeek hottestRepoCreatedLastWeek = null;
		List<HottestRepoCreatedLastWeek> hottestRepoList = new ArrayList<HottestRepoCreatedLastWeek>();

		String data = restTemplate.getForObject(GitRepoBaseUrl + "repositories?q=created:", String.class);
		JSONObject obj = null;
		JSONArray arr = null;
		try {
			obj = new JSONObject(data);
			arr = obj.getJSONArray("items");
		} catch (JSONException e) {
			LOGGER.error("JSON Exception : " +e.getMessage());			
		}

		if (arr != null) {
			for (int i = 0; i < arr.length(); i++) {
				try {
					// get Data from API and assign to local variable
					String createdAt = arr.getJSONObject(i).getString("updated_at");
					String watchersCount = arr.getJSONObject(i).getString("watchers_count");
					String language = arr.getJSONObject(i).getString("language");
					String description = arr.getJSONObject(i).getString("description");
					String name = arr.getJSONObject(i).getString("name");
					String htmlURL = arr.getJSONObject(i).getString("html_url");
                   
					// get Formatted date , convert string formatted date into Date Formatted
					Date repoCreatedDate = DateUtility.getFormattedDate(createdAt);
					/* get date of previous 7th day date*/
					Date lastWeekRecords = DateUtility.getPreviousSevenDaysdate();
					
					/*
					 * get the records by compare current date to previous 7th day date 
					 * 
					 *
					 */
					if (repoCreatedDate.after(lastWeekRecords)) {
                     // set the API date to POJO object
						hottestRepoCreatedLastWeek = new HottestRepoCreatedLastWeek();
						hottestRepoCreatedLastWeek.setHtmlUrl(htmlURL);
						hottestRepoCreatedLastWeek.setName(name);
						hottestRepoCreatedLastWeek.setLanguage(language);
						hottestRepoCreatedLastWeek.setDescription(description);
						hottestRepoCreatedLastWeek.setWatchersCount(watchersCount);
                      
						// store POJO object in List  
						hottestRepoList.add(hottestRepoCreatedLastWeek);
						
						// Apply sorting descending  order
						Collections.sort(hottestRepoList, new SortRepoData());
					}
				} catch (JSONException e) {
					LOGGER.error("JSON object is empty or null :"+e.getMessage());
					
				}

			}
		} else {
			LOGGER.error("JSONObj Array is null");
		}
	return hottestRepoList;

	}
}
