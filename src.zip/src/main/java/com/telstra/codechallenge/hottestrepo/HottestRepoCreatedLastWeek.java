package com.telstra.codechallenge.hottestrepo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class HottestRepoCreatedLastWeek {

	private String htmlUrl;
	private String watchersCount;
	private String language;
	private String description;
	private String name;
	
	
	public String getHtmlUrl() {
		return htmlUrl;
	}
	public void setHtmlUrl(String htmlUrl) {
		this.htmlUrl = htmlUrl;
	}
	public String getWatchersCount() {
		return watchersCount;
	}
	public void setWatchersCount(String watchersCount) {
		this.watchersCount = watchersCount;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	

	@Override
	public String toString() {
		return "HottestRepoCreatedLastWeek [htmlUrl=" + htmlUrl + ", watchersCount=" + watchersCount + ", language="
				+ language + ", description=" + description + ", name=" + name + "]";
	}
	
	
}
